# Code

## Setup
```bash
pip install -r requirements.txt          # stim, pymatching, torch, numpy, pandas, scipy, scikit-learn, matplotlib
cd src
```
Unzip `code.zip` inside the submission folder so that `code/`, `training data/`, `testing data/` and `results/` sit side by side; the default paths below then work as written.

## Run everything (about 50 min on 2× NVIDIA T4, e.g. Kaggle free tier)
```bash
python run_all.py --data_dir '../../training data' --out_dir ../../results
```
Each stage can also be run on its own:

| Script | What it does |
|---|---|
| `config.py` | All settings: noise levels, shot counts, seeds, epochs, channels. `QEC_QUICK=1` gives a tiny smoke test |
| `circuits.py` | Builds the Stim circuit and runs the MWPM / correlated-MWPM decoders (PyMatching). Maps detectors to the 3D space-time grid |
| `data.py` | Generates the dataset in parallel on all CPU cores and saves the train/val/test splits. Includes the loaders (test files are read from `testing data/`) |
| `models.py` | Residual 3D-CNN (ours), the hybrid CNN + correlated-MWPM decoder, and the MLP ablation |
| `training.py` | Training loop (data held on the GPU, mixed precision, one-cycle learning rate, best-validation checkpoint) and inference |
| `scheduler.py` | Runs jobs in parallel, one worker per GPU, largest jobs first |
| `train.py` | Trains 3 CNN seeds plus 1 hybrid per code distance and saves weights to `results/model_weights/simulation` |
| `evaluate.py` | Scores every decoder on all test files, runs paired McNemar tests and the out-of-distribution test, and writes the CSVs |
| `hardware.py` | Google Sycamore experiment: downloads the data, pre-trains on the device-fitted error model, fine-tunes on half the real shots, tests on the other half (2 folds × 4 patches) |
| `figures.py` | Draws every paper figure from the CSV tables |
| `run_all.py` | Runs the stages in order (`--skip data,hardware,...` to skip some) |
| `v1_ablation_models.py` | Model definitions for the preliminary run (MLP ablation and the larger dense-head CNN) |

Common uses:
```bash
python figures.py   --data_dir '../../training data' --out_dir ../../results   # redraw figures from the saved tables
python evaluate.py  --data_dir '../../training data' --out_dir ../../results   # re-score the saved weights (works on CPU)
python hardware.py  --out_dir ../../results                           # real-hardware experiment only
```

## How it works
1. **Data:** Stim simulates the noisy surface-code circuit and records which parity checks fired (the *detectors*) and whether the logical qubit flipped (the *label*).
2. **3D picture:** each detector has an (x, y, time) coordinate, so a shot becomes a small 3D image (4×4×4 for d=3, 6×6×6 for d=5).
3. **CNN:** small 3×3×3 filters slide over space and time to find local error clusters. A 1×1×1 squeeze and a small dense head then output P(flip).
4. **Baselines:** MWPM and correlated MWPM, both given the true noise model.
5. **Evaluation:** every decoder sees the same shots, so differences are tested with the exact McNemar test.

## Notebooks
- `notebooks/qec_neural_decoder_v2.ipynb` is the final experiment as one Kaggle notebook. It produced every number in the paper.
- `notebooks/qec_neural_decoder.ipynb` is the preliminary run, which includes the MLP ablation.

Kaggle settings: Accelerator **GPU T4 ×2**, Internet **On**, then Run All.

The scripts above are a clean modular version of the final notebook, with the same settings and seeds. The paper's numbers were produced by the notebook.

## Libraries
Everything is installed with `pip install -r requirements.txt`:

| Library | Role |
|---|---|
| Stim | circuit simulation and data generation |
| PyMatching | MWPM and correlated-MWPM baselines |
| PyTorch | neural networks and GPU training |
| NumPy, pandas | arrays and tables |
| SciPy | McNemar tests |
| scikit-learn | ROC/AUC |
| matplotlib | figures |
