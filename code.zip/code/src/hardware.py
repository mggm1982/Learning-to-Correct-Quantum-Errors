"""Real-hardware experiment on Google Sycamore surface-code data (Zenodo 10.5281/zenodo.6804040).

Protocol per patch (d=3, 5 rounds, Z basis) and fold:
  fold A: pre-train on shots sampled from pij_from_even_for_odd.dem -> fine-tune on real EVEN shots -> test on real ODD shots
  fold B: the mirror image. MWPM / correlated MWPM use the same fitted error model, so no decoder sees the test shots.

    python hardware.py --out_dir ../../results [--hw_dir path/to/extracted/data]
"""
import argparse, glob, os, threading, urllib.request, zipfile
import numpy as np
import pandas as pd
import stim
import torch
from scipy.stats import binomtest
import config as C
from circuits import matcher, decode, layout_from_coords, to_grid
from models import build
from training import fit, predict
from scheduler import run_parallel


def download(hw_dir):
    os.makedirs(hw_dir, exist_ok=True)
    if glob.glob(f"{hw_dir}/**/surface_code_bZ_d3_r*", recursive=True):
        return
    zp = f"{hw_dir}/data.zip"
    print("downloading Google Sycamore data (315 MB) ...", flush=True)
    urllib.request.urlretrieve(C.HW["url"], zp)
    with zipfile.ZipFile(zp) as z:
        z.extractall(hw_dir, members=[n for n in z.namelist() if f"_d3_r{C.HW['rounds']:02d}_" in n and "_bZ_" in n])
    os.remove(zp)


def read_folder(folder):
    stims = sorted(glob.glob(f"{folder}/circuit_ideal*.stim")) or sorted(glob.glob(f"{folder}/*.stim"))
    circ = stim.Circuit.from_file(stims[0]); nd = circ.num_detectors
    det = stim.read_shot_data_file(path=f"{folder}/detection_events.b8", format="b8", num_detectors=nd).astype(np.uint8)
    obs = stim.read_shot_data_file(path=f"{folder}/obs_flips_actual.01", format="01", num_observables=1)[:, 0].astype(np.uint8)
    return circ, det, obs


def run_fold(folder, fold, dev, wdir, seed=7):
    circ, det, obs = read_folder(folder)
    lay = layout_from_coords(circ.get_detector_coordinates())        # the hardware circuit's own coordinates
    src, tst = (0, 1) if fold == "A" else (1, 0)
    dem_path = f"{folder}/{'pij_from_even_for_odd.dem' if fold == 'A' else 'pij_from_odd_for_even.dem'}"
    if not os.path.exists(dem_path):
        dem_path = (glob.glob(f"{folder}/*.dem") or [None])[0]
    dem = stim.DetectorErrorModel.from_file(dem_path) if dem_path else circ.detector_error_model(decompose_errors=True)
    assert dem.num_detectors == det.shape[1], "error model / data detector mismatch"
    mc, mp = matcher(dem, True), matcher(dem, False)
    sd, so, _ = dem.compile_sampler(seed=seed).sample(C.HW["pretrain_shots"])        # synthetic pre-training shots
    sd, so = sd.astype(np.uint8), so[:, 0].astype(np.uint8); sc, _ = decode(mc, sd, True)
    Ds, Os, Dt, Ot = det[src::2], obs[src::2], det[tst::2], obs[tst::2]
    Cs, _ = decode(mc, Ds, True); Ct, _ = decode(mc, Dt, True); Pt, _ = decode(mp, Dt, False)
    nv = len(Os) // 10
    Gs, Gt, Gsyn = to_grid(Ds, lay), to_grid(Dt, lay), to_grid(sd, lay)
    row = dict(patch=os.path.basename(folder), fold=fold, dem=os.path.basename(dem_path or "circuit"), test_shots=len(Ot),
               grid=str(lay[1]), mwpm=float((Pt != Ot).mean()), corr_mwpm=float((Ct != Ot).mean()))
    for f in sorted(glob.glob(f"{folder}/obs_flips_predicted_by_*.01")):              # Google's own decoders
        pr = stim.read_shot_data_file(path=f, format="01", num_observables=1)[:, 0].astype(np.uint8)[tst::2]
        row["google_" + os.path.basename(f)[len("obs_flips_predicted_by_"):-3]] = float((pr != Ot).mean())
    for kind in ("cnn", "hybrid"):
        h = kind == "hybrid"
        m = build(kind, lay[1], 32, seed)
        fit(m, Gsyn, so, sc if h else None, Gs[:nv], Os[:nv], Cs[:nv] if h else None, C.HW["pre_epochs"], dev, seed, tag=f"hw {kind} {fold} pre")
        row[f"{kind}_pretrained_only"] = float(((predict(m, Gt, Ct if h else None) > .5) != Ot).mean())
        fit(m, Gs[nv:], Os[nv:], Cs[nv:] if h else None, Gs[:nv], Os[:nv], Cs[:nv] if h else None, C.HW["ft_epochs"], dev, seed,
            lr=C.HW["ft_lr"], bs=C.HW["ft_batch"], tag=f"hw {kind} {fold} ft")
        pt = predict(m, Gt, Ct if h else None) > .5
        row[f"{kind}_finetuned"] = float((pt != Ot).mean())
        n01, n10 = int(((pt != Ot) & (Ct == Ot)).sum()), int(((Ct != Ot) & (pt == Ot)).sum())
        row[f"{kind}_vs_corr_mcnemar_p"] = binomtest(n01, n01 + n10).pvalue if n01 + n10 else 1.0
        torch.save(m.state_dict(), f"{wdir}/hw_{kind}_{row['patch']}_fold{fold}.pt")
    return row


def main(out_dir, hw_dir):
    download(hw_dir)
    folders = sorted(f for f in glob.glob(f"{hw_dir}/**/surface_code_bZ_d3_r{C.HW['rounds']:02d}_center_*", recursive=True) if os.path.isdir(f))
    print("patches:", [os.path.basename(f) for f in folders])
    wdir = f"{out_dir}/model_weights/hardware_sycamore"; os.makedirs(wdir, exist_ok=True)
    rows, lock = [], threading.Lock()

    def job(folder, fold):
        def fn(dev):
            r = run_fold(folder, fold, dev, wdir)
            with lock:
                rows.append(r)
            print("HW:", r, flush=True)
        return fn
    run_parallel([(1, f"{os.path.basename(f)}_{fo}", job(f, fo)) for f in folders for fo in (("A", "B") if C.HW["both_folds"] else ("A",))])
    os.makedirs(f"{out_dir}/tables", exist_ok=True)
    df = pd.DataFrame(rows).sort_values(["patch", "fold"]); df.to_csv(f"{out_dir}/tables/results_hardware.csv", index=False)
    print(df.to_string(index=False))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out_dir", default="../../results")
    ap.add_argument("--hw_dir", default="./sycamore_data")
    a = ap.parse_args(); main(a.out_dir, a.hw_dir)
