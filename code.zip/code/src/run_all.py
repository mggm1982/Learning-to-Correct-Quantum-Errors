"""Full pipeline: generate data -> train -> evaluate -> hardware experiment -> figures.

    python run_all.py                       # full run (about 50 min on 2x NVIDIA T4)
    QEC_QUICK=1 python run_all.py --data_dir /tmp/qd --out_dir /tmp/qr      # 3-minute smoke test
Skip stages with --skip data,hardware etc.
"""
import argparse, time
import data, train, evaluate, hardware, figures

ap = argparse.ArgumentParser()
ap.add_argument("--data_dir", default="../../training data")
ap.add_argument("--out_dir", default="../../results")
ap.add_argument("--hw_dir", default="./sycamore_data")
ap.add_argument("--skip", default="", help="comma-separated: data,train,evaluate,hardware,figures")
a = ap.parse_args(); skip = set(filter(None, a.skip.split(",")))
t0 = time.time()
if "data" not in skip: data.generate(a.data_dir)
if "train" not in skip: train.main(a.data_dir, a.out_dir)
if "evaluate" not in skip: evaluate.main(a.data_dir, a.out_dir)
if "hardware" not in skip:
    try:
        hardware.main(a.out_dir, a.hw_dir)
    except Exception as e:
        print("hardware stage skipped:", repr(e))
if "figures" not in skip: figures.main(a.data_dir, a.out_dir)
print(f"done in {(time.time()-t0)/60:.1f} min")
