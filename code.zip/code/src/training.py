"""Training loop (whole dataset on GPU, mixed precision, one-cycle LR, best-validation checkpoint) and inference."""
import copy, math, time
import numpy as np
import torch
import torch.nn.functional as F


@torch.no_grad()
def predict(model, X, aux=None, bs=16384):
    """Returns P(logical flip) for every shot."""
    dev = next(model.parameters()).device
    model.eval(); out = []
    for i in range(0, len(X), bs):
        xb = torch.as_tensor(X[i:i + bs], device=dev).float()
        ab = None if aux is None else torch.as_tensor(aux[i:i + bs], device=dev).float()
        with torch.autocast(dev.type, enabled=dev.type == "cuda"):
            out.append(torch.sigmoid(model(xb, ab)).float().cpu())
    return torch.cat(out).numpy()


def ler(prob, y):
    return float(((prob > 0.5) != y).mean())


def fit(model, X, y, aux, Xv, yv, auxv, epochs, device, seed, lr=3e-3, bs=4096, tag=""):
    """Trains in place and restores the checkpoint with the lowest validation logical error rate.
    The untrained model (epoch 0) is also a candidate checkpoint, so fine-tuning can never make things worse on validation."""
    model.to(device); cuda = device.startswith("cuda")
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, lr, total_steps=epochs * math.ceil(len(y) / bs))
    scaler = torch.amp.GradScaler("cuda", enabled=cuda)
    Xg, yg = torch.as_tensor(X, device=device), torch.as_tensor(y, device=device).float()
    ag = None if aux is None else torch.as_tensor(aux, device=device).float()
    gen = torch.Generator(device=device).manual_seed(seed)
    v0 = ler(predict(model, Xv, auxv), yv)
    hist, best, best_sd, t0 = [dict(epoch=0, train_loss=float("nan"), val_ler=v0)], v0, copy.deepcopy(model.state_dict()), time.time()
    for ep in range(1, epochs + 1):
        model.train(); perm = torch.randperm(len(yg), device=device, generator=gen); tot = torch.zeros((), device=device)
        for i in range(0, len(yg), bs):
            b = perm[i:i + bs]
            with torch.autocast(device.split(":")[0], enabled=cuda):
                loss = F.binary_cross_entropy_with_logits(model(Xg[b].float(), None if ag is None else ag[b]), yg[b])
            opt.zero_grad(set_to_none=True); scaler.scale(loss).backward(); scaler.step(opt); scaler.update(); sched.step()
            tot += loss.detach() * len(b)
        v = ler(predict(model, Xv, auxv), yv)
        hist.append(dict(epoch=ep, train_loss=tot.item() / len(yg), val_ler=v))
        if v < best:
            best, best_sd = v, copy.deepcopy(model.state_dict())
        print(f"  [{tag} {device}] epoch {ep}/{epochs}  loss {hist[-1]['train_loss']:.4f}  val LER {v:.5f}  ({time.time()-t0:.0f}s)", flush=True)
    model.load_state_dict(best_sd)
    del Xg, yg, ag
    if cuda:
        torch.cuda.empty_cache()
    return hist
