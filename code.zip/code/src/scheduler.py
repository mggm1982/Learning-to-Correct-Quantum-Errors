"""Runs a list of jobs in parallel, one worker thread per GPU, largest jobs first."""
import queue, threading, time
import torch


def devices():
    n = torch.cuda.device_count()
    return [f"cuda:{i}" for i in range(n)] or ["cpu"]


def run_parallel(jobs):
    """jobs: list of (cost, name, fn(device)). Exceptions are reported, not raised."""
    q = queue.Queue()
    for j in sorted(jobs, key=lambda j: -j[0]):
        q.put(j)

    def worker(dev):
        while True:
            try:
                _, name, fn = q.get_nowait()
            except queue.Empty:
                return
            t = time.time(); print(f">>> {name} on {dev}", flush=True)
            try:
                fn(dev)
            except Exception as e:
                print(f"!!! {name} failed: {e!r}", flush=True)
            print(f"<<< {name} done in {(time.time()-t)/60:.1f} min", flush=True)

    threads = [threading.Thread(target=worker, args=(d,)) for d in devices()]
    [t.start() for t in threads]; [t.join() for t in threads]
