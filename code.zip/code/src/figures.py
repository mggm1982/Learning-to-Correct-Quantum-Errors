"""Paper figures from the result tables.

    python figures.py --data_dir '../../training data' --out_dir ../../results
"""
import argparse, os
import numpy as np
import pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from circuits import sim_layout, to_grid
from data import load_npz, test_path

COL = {"cnn": "#2a78d6", "corr": "#eb6834", "mwpm": "#1baf7a", "hyb": "#eda100", "mlp": "#e87ba4", "grey": "#9a9a94"}
plt.rcParams.update({"font.family": "serif", "font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": "#e6e6e3", "grid.linewidth": .5, "legend.frameon": False,
                     "savefig.bbox": "tight", "savefig.dpi": 300, "lines.linewidth": 1.5, "lines.markersize": 4.5})


def se(x, n):
    return np.sqrt(np.maximum(x, 1 / n) * (1 - x) / n)


def main(data_dir, out_dir):
    T, F = f"{out_dir}/tables", f"{out_dir}/figures"; os.makedirs(F, exist_ok=True)
    r = pd.read_csv(f"{T}/results_test.csv")
    seeds = [c for c in r.columns if c.startswith("cnn_s")]
    lo, hi = r[seeds].min(axis=1), r[seeds].max(axis=1)

    fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.7), sharey=True)                      # LER vs p
    for a, d in zip(ax, (3, 5)):
        m = r.d == d; s = r[m]
        a.errorbar(s.p, s.mwpm, se(s.mwpm, s.n), color=COL["mwpm"], marker="s", ls="--", capsize=1.5, label="MWPM")
        a.errorbar(s.p, s.corr_mwpm, se(s.corr_mwpm, s.n), color=COL["corr"], marker="D", ls="-.", capsize=1.5, label="Correlated MWPM")
        if "hybrid" in s:
            a.errorbar(s.p, s.hybrid, se(s.hybrid, s.n), color=COL["hyb"], marker="^", ls=":", capsize=1.5, label="Hybrid CNN+corr. MWPM")
        a.fill_between(s.p, lo[m], hi[m], color=COL["cnn"], alpha=.25, lw=0, label="3D-CNN, range of seeds")
        a.errorbar(s.p, s.cnn_ensemble, se(s.cnn_ensemble, s.n), color=COL["cnn"], marker="o", capsize=1.5, label="3D-CNN ensemble (ours)", zorder=5)
        a.set(xscale="log", yscale="log", xlabel="physical error rate $p$", title=f"distance $d={d}$")
    ax[0].set_ylabel("logical error rate"); ax[1].legend(loc="lower right", fontsize=6.8)
    plt.savefig(f"{F}/ler_vs_p.pdf"); plt.savefig(f"{F}/ler_vs_p.png"); plt.close()

    fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.4), sharey=True)                      # vs correlated MWPM
    for a, d in zip(ax, (3, 5)):
        m = r.d == d; s = r[m]; rel = lambda v: 100 * (s.corr_mwpm - v) / s.corr_mwpm
        a.fill_between(s.p, rel(hi[m]), rel(lo[m]), color=COL["cnn"], alpha=.25, lw=0, label="3D-CNN, seed range")
        a.plot(s.p, rel(s.cnn_ensemble), color=COL["cnn"], marker="o", label="3D-CNN ensemble")
        if "hybrid" in s:
            a.plot(s.p, rel(s.hybrid), color=COL["hyb"], marker="^", ls=":", label="Hybrid")
        a.plot(s.p, rel(s.mwpm), color=COL["mwpm"], marker="s", ls="--", label="MWPM")
        a.axhline(0, color="#555", lw=.8); a.set(xscale="log", xlabel="physical error rate $p$", title=f"$d={d}$", ylim=(-45, 50))
    ax[0].set_ylabel("LER reduction vs corr. MWPM (%)")
    fig.legend(*ax[0].get_legend_handles_labels(), loc="upper center", ncol=4, fontsize=7, bbox_to_anchor=(.5, 1.1))
    plt.savefig(f"{F}/vs_corr.pdf"); plt.savefig(f"{F}/vs_corr.png"); plt.close()

    fig, a = plt.subplots(figsize=(3.4, 2.5))                                            # threshold
    curves = [(r, "mwpm", COL["mwpm"], "s", "--", "MWPM"), (r, "corr_mwpm", COL["corr"], "D", "-.", "Correlated MWPM"),
              (r, "cnn_ensemble", COL["cnn"], "o", "-", "3D-CNN ensemble")]
    if os.path.exists(f"{T}/v1_ablation_results_test.csv"):
        curves.append((pd.read_csv(f"{T}/v1_ablation_results_test.csv"), "mlp", COL["mlp"], "v", ":", "MLP (ablation)"))
    for df, k, c, mk, ls, l in curves:
        x = df[df.d == 3].set_index("p")[k]; y = df[df.d == 5].set_index("p")[k]
        a.plot(x.index, y / x, color=c, marker=mk, ls=ls, label=l)
    a.axhline(1, color="#555", lw=.8)
    a.set(xscale="log", yscale="log", xlabel="physical error rate $p$", ylabel=r"$\Lambda^{-1}$ = LER($d$=5)/LER($d$=3)"); a.legend(fontsize=6.5)
    plt.savefig(f"{F}/threshold.pdf"); plt.savefig(f"{F}/threshold.png"); plt.close()

    if os.path.exists(f"{T}/results_hardware.csv"):                                      # hardware
        h = pd.read_csv(f"{T}/results_hardware.csv").sort_values(["patch", "fold"])
        cols = [("mwpm", "MWPM", COL["mwpm"]), ("corr_mwpm", "Correlated MWPM", COL["corr"]),
                ("google_belief_matching", "Belief matching [Google]", "#7a7a74"),
                ("google_tensor_network_contraction", "Tensor network [Google]", "#c3c2b7"), ("cnn_finetuned", "3D-CNN (ours)", COL["cnn"])]
        cols = [c for c in cols if c[0] in h]
        fig, a = plt.subplots(figsize=(7.1, 2.5)); w = .8 / len(cols)
        for i, (k, l, c) in enumerate(cols):
            a.bar(np.arange(len(h)) + (i - (len(cols) - 1) / 2) * w, 100 * h[k], w * .9, color=c, label=l)
        vals = 100 * h[[c[0] for c in cols]].values
        a.set(xticks=range(len(h)), xticklabels=[f"({x.patch.split('center_')[-1].replace('_', ',')}) {x.fold}" for x in h.itertuples()],
              ylabel="logical error rate (%)", ylim=(vals.min() * .9, vals.max() * 1.04), xlabel="Sycamore patch (center qubit) and fold")
        a.grid(axis="x", visible=False); a.legend(ncol=5, fontsize=6.5, loc="upper center", bbox_to_anchor=(.5, 1.15))
        plt.savefig(f"{F}/hardware.pdf"); plt.savefig(f"{F}/hardware.png"); plt.close()

    if os.path.exists(f"{T}/ensemble_d5_p0.006_probs.npz"):                              # ROC / calibration / post-selection
        z = np.load(f"{T}/ensemble_d5_p0.006_probs.npz"); p, y = z["ens"], z["y"]
        fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.2))
        fp, tp, _ = roc_curve(y, p); ax[0].plot(fp, tp, color=COL["cnn"], label=f"AUC = {auc(fp, tp):.4f}"); ax[0].plot([0, 1], [0, 1], ":", color="#555")
        ax[0].set(xlabel="false positive rate", ylabel="true positive rate", title="ROC"); ax[0].legend(loc="lower right")
        b = np.linspace(0, 1, 11); idx = np.digitize(p, b[1:-1]); mid = (b[1:] + b[:-1]) / 2
        ax[1].plot(mid, [y[idx == i].mean() if (idx == i).sum() > 30 else np.nan for i in range(10)], "o-", color=COL["cnn"])
        ax[1].plot([0, 1], [0, 1], ":", color="#555"); ax[1].set(xlabel="predicted P(flip)", ylabel="observed flip frequency", title="Calibration")
        conf = np.abs(p - .5) * 2; qs = np.linspace(0, .5, 26)
        lers = [max(((p[k] > .5) != y[k]).mean(), 1e-6) for k in (conf >= np.quantile(conf, q) for q in qs)]
        ax[2].plot(100 * qs, lers, color=COL["cnn"]); ax[2].set(yscale="log", xlabel="least-confident shots discarded (%)", ylabel="logical error rate", title="Post-selection")
        plt.tight_layout(); plt.savefig(f"{F}/classifier.pdf"); plt.savefig(f"{F}/classifier.png"); plt.close()

    if os.path.exists(f"{T}/results_ood.csv"):                                           # out-of-distribution
        o = pd.read_csv(f"{T}/results_ood.csv")
        keys = [("mwpm_assumed_model", "MWPM (assumed model)", COL["mwpm"]), ("corr_mwpm_assumed_model", "Corr. MWPM (assumed)", COL["corr"]),
                ("mwpm_true_model", "MWPM (oracle, true model)", COL["grey"]), ("hybrid", "Hybrid", COL["hyb"]), ("cnn_ensemble", "3D-CNN ensemble", COL["cnn"])]
        keys = [k for k in keys if k[0] in o]
        fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.3))
        for a, d in zip(ax, (3, 5)):
            s = o[o.d == d].reset_index(); w = .8 / len(keys)
            for i, (k, l, c) in enumerate(keys):
                a.bar(np.arange(len(s)) + (i - (len(keys) - 1) / 2) * w, 100 * s[k], w * .9, color=c, label=l)
            a.set(xticks=range(len(s)), xticklabels=[f"$p$={x}" for x in s.p], ylabel="logical error rate (%)", title=f"$d={d}$, measurement/reset noise $\\times5$")
            a.grid(axis="x", visible=False)
        fig.legend(*ax[0].get_legend_handles_labels(), loc="upper center", ncol=5, fontsize=6.5, bbox_to_anchor=(.5, 1.1))
        plt.savefig(f"{F}/ood.pdf"); plt.savefig(f"{F}/ood.png"); plt.close()

    p_path = test_path(data_dir, 5, 0.006)                                                # example syndrome
    if os.path.exists(p_path):
        det, obs, _ = load_npz(p_path); g = to_grid(det, sim_layout(5)); k = det.sum(1)
        i = int(np.argmax((k >= 8) & (k <= 11)))
        fig, ax = plt.subplots(1, g.shape[1], figsize=(7.1, 1.45))
        for t in range(g.shape[1]):
            ax[t].imshow(g[i, t].T, cmap="Blues", vmin=0, vmax=1.4); ax[t].set(title=f"round {t+1}", xticks=[], yticks=[]); ax[t].grid(False)
        fig.suptitle(f"One $d=5$ shot at $p=0.006$: {det[i].sum()} detection events; logical flip = {obs[i]}", y=1.08, fontsize=8)
        plt.savefig(f"{F}/syndrome.pdf"); plt.savefig(f"{F}/syndrome.png"); plt.close()
    print("figures written to", F)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="../../training data")
    ap.add_argument("--out_dir", default="../../results")
    a = ap.parse_args(); main(a.data_dir, a.out_dir)
