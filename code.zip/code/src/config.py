"""Experiment configuration. Set QEC_QUICK=1 in the environment for a tiny smoke test."""
import os

QUICK = os.environ.get("QEC_QUICK", "0") == "1"
SEED = 42

DISTANCES = [3, 5]
P_TRAIN = [0.002, 0.004, 0.006, 0.008, 0.010]                               # training noise mix
P_TEST = [0.001, 0.002, 0.003, 0.004, 0.005, 0.006, 0.008, 0.010, 0.012]     # held-out test levels
P_OOD = [0.004, 0.008]                                                      # out-of-distribution levels
OOD_BIAS = 5.0                                                              # measurement/reset noise x5

N_TRAIN = {3: 2_000_000, 5: 3_000_000}      # base training set (identical to the preliminary v1 run)
N_EXTRA = {3: 0, 5: 1_000_000}              # extra d=5 training shots (new seeds)
N_VAL, N_TEST = 100_000, 200_000

SEEDS = [1, 2, 3]                           # independent training seeds
EPOCHS = {3: 8, 5: 6}
CHANNELS = {3: 48, 5: 32}
LR, BATCH = 3e-3, 4096

HW = dict(rounds=5, pretrain_shots=400_000, pre_epochs=5, ft_epochs=4, ft_lr=5e-4, ft_batch=1024, both_folds=True,
          url="https://zenodo.org/records/6804040/files/google_qec3v5_experiment_data.zip?download=1")

if QUICK:
    N_TRAIN, N_EXTRA, N_VAL, N_TEST = {3: 20_000, 5: 20_000}, {3: 0, 5: 5_000}, 4_000, 5_000
    P_TEST, SEEDS, EPOCHS = [0.002, 0.006, 0.010], [1, 2], {3: 1, 5: 1}
    HW.update(pretrain_shots=5_000, pre_epochs=1, ft_epochs=1)
