"""Train the simulation decoders: 3 seeds of the 3D-CNN and one hybrid per code distance.

    python train.py --data_dir '../../training data' --out_dir ../../results
"""
import argparse, json, os, threading
import numpy as np
import torch
import config as C
from circuits import sim_layout, to_grid
from data import load_split
from models import build, n_params
from training import fit
from scheduler import run_parallel


def main(data_dir, out_dir, kinds=("cnn", "hybrid")):
    wdir = f"{out_dir}/model_weights/simulation"; os.makedirs(wdir, exist_ok=True)
    torch.backends.cudnn.benchmark = True
    data, lay = {}, {d: sim_layout(d) for d in C.DISTANCES}
    for d in C.DISTANCES:
        for s in ("train", "val"):
            det, y, corr = load_split(data_dir, s, d)
            data[(s, d)] = (to_grid(det, lay[d]), y, corr)
        print(f"d={d}: train {len(data[('train', d)][1]):,}  val {len(data[('val', d)][1]):,}  grid {lay[d][1]}")

    hists, lock = {}, threading.Lock()

    def job(kind, d, seed):
        def fn(dev):
            (X, y, c), (Xv, yv, cv) = data[("train", d)], data[("val", d)]
            m = build(kind, lay[d][1], C.CHANNELS[d], seed)
            use_aux = kind == "hybrid"
            h = fit(m, X, y, c if use_aux else None, Xv, yv, cv if use_aux else None, C.EPOCHS[d], dev, seed,
                    lr=C.LR, bs=C.BATCH, tag=f"{kind}_d{d}_s{seed}")
            torch.save(m.state_dict(), f"{wdir}/{kind}_d{d}_s{seed}.pt")
            with lock:
                hists[f"{kind}_d{d}_s{seed}"] = dict(history=h, params=n_params(m))
        return fn

    jobs = []
    for d in C.DISTANCES:
        cost = len(data[("train", d)][1]) * C.EPOCHS[d] * np.prod(lay[d][1]) * C.CHANNELS[d] ** 2
        if "cnn" in kinds:
            jobs += [(cost, f"cnn_d{d}_s{s}", job("cnn", d, s)) for s in C.SEEDS]
        if "hybrid" in kinds:
            jobs.append((cost, f"hybrid_d{d}_s{C.SEEDS[0]}", job("hybrid", d, C.SEEDS[0])))
    run_parallel(jobs)
    os.makedirs(f"{out_dir}/tables", exist_ok=True)
    json.dump(hists, open(f"{out_dir}/tables/training_history.json", "w"), indent=1)
    print("weights saved to", wdir)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="../../training data")
    ap.add_argument("--out_dir", default="../../results")
    a = ap.parse_args(); main(a.data_dir, a.out_dir)
