"""Neural decoders: residual 3D CNN (ours), matching-assisted hybrid, and the MLP ablation."""
import threading
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class ResBlock(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.c1, self.b1 = nn.Conv3d(ch, ch, 3, padding=1, bias=False), nn.BatchNorm3d(ch)
        self.c2, self.b2 = nn.Conv3d(ch, ch, 3, padding=1, bias=False), nn.BatchNorm3d(ch)

    def forward(self, x):
        return F.gelu(x + self.b2(self.c2(F.gelu(self.b1(self.c1(x))))))


class CNN3D(nn.Module):
    """Input: (batch, T, X, Y) detector volume. Output: one logit = log-odds that the logical qubit flipped.
    hybrid=True also takes the correlated-MWPM decision (0/1) and starts out identical to it."""

    def __init__(self, shape, ch=32, blocks=3, hybrid=False, squeeze=8):
        super().__init__()
        self.hybrid = hybrid
        V = int(np.prod(shape))
        self.stem = nn.Sequential(nn.Conv3d(1, ch, 3, padding=1, bias=False), nn.BatchNorm3d(ch), nn.GELU())
        self.body = nn.Sequential(*[ResBlock(ch) for _ in range(blocks)])
        self.squeeze = nn.Sequential(nn.Conv3d(ch, squeeze, 1, bias=False), nn.BatchNorm3d(squeeze), nn.GELU())
        self.head = nn.Sequential(nn.Linear(squeeze * V + int(hybrid), 256), nn.GELU(), nn.Dropout(0.1), nn.Linear(256, 1))
        if hybrid:
            self.alpha = nn.Parameter(torch.tensor(4.0))

    def forward(self, x, aux=None):
        h = self.squeeze(self.body(self.stem(x.unsqueeze(1)))).flatten(1)
        if not self.hybrid:
            return self.head(h).squeeze(1)
        s = 2 * aux - 1
        return self.head(torch.cat([h, s.unsqueeze(1)], 1)).squeeze(1) + self.alpha * s


class MLP(nn.Module):
    """Ablation: no notion of which detectors are neighbours."""

    def __init__(self, n_in, h=512):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(n_in, h), nn.ReLU(), nn.Linear(h, h), nn.ReLU(),
                                 nn.Linear(h, h // 2), nn.ReLU(), nn.Linear(h // 2, 1))

    def forward(self, x, aux=None):
        return self.net(x.flatten(1)).squeeze(1)


_INIT_LOCK = threading.Lock()


def build(kind, shape, ch=32, seed=0):
    """kind in {'cnn','hybrid','mlp'}; seeding is thread-safe so GPUs can build models in parallel."""
    with _INIT_LOCK:
        torch.manual_seed(seed)
        if kind == "mlp":
            return MLP(int(np.prod(shape)))
        return CNN3D(shape, ch=ch, hybrid=(kind == "hybrid"))


def n_params(m):
    return sum(p.numel() for p in m.parameters())


def load(kind, shape, ch, path, device="cpu"):
    m = build(kind, shape, ch)
    m.load_state_dict(torch.load(path, map_location=device))
    return m.to(device).eval()
