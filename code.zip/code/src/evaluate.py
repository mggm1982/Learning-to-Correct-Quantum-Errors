"""Evaluate MWPM, correlated MWPM, the 3 CNN seeds, their ensemble and the hybrid on every test file,
with exact paired McNemar tests, plus the out-of-distribution test.

    python evaluate.py --data_dir '../../training data' --out_dir ../../results
Writes tables/results_test.csv, tables/mcnemar.csv, tables/results_ood.csv, tables/ensemble_d5_p0.006_probs.npz
"""
import argparse, os
import numpy as np
import pandas as pd
import torch
from scipy.stats import binomtest
import config as C
from circuits import make_circuit, matcher, decode, sim_layout, to_grid
from data import load_npz, test_path, ood_path
from models import load
from training import predict


def mcnemar(a_wrong, b_wrong):
    n01, n10 = int((a_wrong & ~b_wrong).sum()), int((b_wrong & ~a_wrong).sum())
    return n01, n10, (binomtest(n01, n01 + n10).pvalue if n01 + n10 else 1.0)


def load_models(out_dir, d, dev):
    lay = sim_layout(d); w = f"{out_dir}/model_weights/simulation"
    seeds = [load("cnn", lay[1], C.CHANNELS[d], f"{w}/cnn_d{d}_s{s}.pt", dev) for s in C.SEEDS if os.path.exists(f"{w}/cnn_d{d}_s{s}.pt")]
    hp = f"{w}/hybrid_d{d}_s{C.SEEDS[0]}.pt"
    hyb = load("hybrid", lay[1], C.CHANNELS[d], hp, dev) if os.path.exists(hp) else None
    return lay, seeds, hyb


def main(data_dir, out_dir):
    dev = "cuda:0" if torch.cuda.is_available() else "cpu"
    tdir = f"{out_dir}/tables"; os.makedirs(tdir, exist_ok=True)
    rows, sig, ood = [], [], []
    for d in C.DISTANCES:
        lay, seeds, hyb = load_models(out_dir, d, dev)
        for p in C.P_TEST:
            det, y, _ = load_npz(test_path(data_dir, d, p)); X = to_grid(det, lay)
            dem = make_circuit(d, p).detector_error_model(decompose_errors=True)
            mw, mw_us = decode(matcher(dem, False), det, False)
            cm, cm_us = decode(matcher(dem, True), det, True)
            probs = [predict(m, X) for m in seeds]; ens = np.mean(probs, 0)
            lers = [float(((q > .5) != y).mean()) for q in probs]
            row = dict(d=d, p=p, n=len(y), mwpm=float((mw != y).mean()), corr_mwpm=float((cm != y).mean()),
                       mwpm_us=mw_us, corr_us=cm_us, cnn_mean=float(np.mean(lers)),
                       cnn_std=float(np.std(lers, ddof=1)) if len(lers) > 1 else 0.0, cnn_ensemble=float(((ens > .5) != y).mean()))
            for s, l in zip(C.SEEDS, lers):
                row[f"cnn_s{s}"] = l
            wrong = {"mwpm": mw != y, "corr_mwpm": cm != y, "cnn_ensemble": (ens > .5) != y}
            if hyb is not None:
                ph = predict(hyb, X, cm); row["hybrid"] = float(((ph > .5) != y).mean()); wrong["hybrid"] = (ph > .5) != y
            rows.append(row); print({k: (round(v, 6) if isinstance(v, float) else v) for k, v in row.items()}, flush=True)
            for a in [k for k in ("cnn_ensemble", "hybrid") if k in wrong]:
                for b in ("mwpm", "corr_mwpm"):
                    n01, n10, pv = mcnemar(wrong[a], wrong[b])
                    sig.append(dict(d=d, p=p, decoder=a, baseline=b, decoder_ler=float(wrong[a].mean()),
                                    baseline_ler=float(wrong[b].mean()), decoder_only_wrong=n01, baseline_only_wrong=n10, mcnemar_p=pv))
            if d == 5 and abs(p - 0.006) < 1e-9:
                np.savez(f"{tdir}/ensemble_d5_p0.006_probs.npz", ens=ens, y=y)
        for p in C.P_OOD:   # decoders assume the training noise model; the oracle knows the true one
            det, y, _ = load_npz(ood_path(data_dir, d, p)); X = to_grid(det, lay)
            dem = make_circuit(d, p).detector_error_model(decompose_errors=True)
            mw, _ = decode(matcher(dem, False), det, False); cm, _ = decode(matcher(dem, True), det, True)
            tr, _ = decode(matcher(make_circuit(d, p, C.OOD_BIAS).detector_error_model(decompose_errors=True), False), det, False)
            ens = np.mean([predict(m, X) for m in seeds], 0)
            r = dict(d=d, p=p, mwpm_true_model=float((tr != y).mean()), mwpm_assumed_model=float((mw != y).mean()),
                     corr_mwpm_assumed_model=float((cm != y).mean()), cnn_ensemble=float(((ens > .5) != y).mean()))
            if hyb is not None:
                r["hybrid"] = float(((predict(hyb, X, cm) > .5) != y).mean())
            ood.append(r)
    pd.DataFrame(rows).to_csv(f"{tdir}/results_test.csv", index=False)
    pd.DataFrame(sig).to_csv(f"{tdir}/mcnemar.csv", index=False)
    pd.DataFrame(ood).to_csv(f"{tdir}/results_ood.csv", index=False)
    print(pd.DataFrame(rows)[["d", "p", "mwpm", "corr_mwpm", "cnn_mean", "cnn_ensemble"] + (["hybrid"] if "hybrid" in rows[0] else [])].to_string(index=False))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="../../training data")
    ap.add_argument("--out_dir", default="../../results")
    a = ap.parse_args(); main(a.data_dir, a.out_dir)
