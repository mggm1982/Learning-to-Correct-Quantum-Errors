"""Surface-code circuits (Stim), matching decoders (PyMatching) and the syndrome -> 3D-grid mapping."""
import time
import numpy as np
import stim
import pymatching


def make_circuit(d, p, bias=1.0):
    """Rotated surface code, Z-basis memory, d rounds, circuit-level depolarizing noise of strength p.
    bias multiplies the measurement and reset error rates (used for the out-of-distribution test)."""
    return stim.Circuit.generated(
        "surface_code:rotated_memory_z", distance=d, rounds=d,
        after_clifford_depolarization=p, before_round_data_depolarization=p,
        before_measure_flip_probability=min(0.5, p * bias), after_reset_flip_probability=min(0.5, p * bias))


def matcher(dem, correlated):
    """MWPM decoder for a detector error model; correlated=True enables correlated matching."""
    if correlated:
        try:
            return pymatching.Matching.from_detector_error_model(dem, enable_correlations=True)
        except Exception as e:  # older PyMatching or a DEM it cannot correlate
            print("correlated matching unavailable, using plain MWPM:", repr(e)[:100])
    return pymatching.Matching.from_detector_error_model(dem)


def decode(m, det, correlated):
    """Returns (predicted logical flips as uint8, microseconds per shot)."""
    t = time.time()
    try:
        pred = m.decode_batch(det, enable_correlations=correlated)
    except Exception:
        pred = m.decode_batch(det)
    return pred[:, 0].astype(np.uint8), (time.time() - t) / max(1, len(det)) * 1e6


def layout_from_coords(coords):
    """Map detector coordinates (x, y, t) to integer indices of a dense (T, X, Y) grid.
    Built from each circuit's OWN coordinates, so it works for simulated and hardware circuits."""
    xyz = np.array([coords[i][:3] for i in range(len(coords))])
    maps = [{v: i for i, v in enumerate(sorted(set(xyz[:, a])))} for a in range(3)]
    idx = np.array([[maps[2][t], maps[0][x], maps[1][y]] for x, y, t in xyz])
    return idx, (len(maps[2]), len(maps[0]), len(maps[1]))


def sim_layout(d):
    return layout_from_coords(make_circuit(d, 0.001).get_detector_coordinates())


def to_grid(det, layout):
    """(shots, n_detectors) 0/1 array -> (shots, T, X, Y) uint8 volume."""
    idx, shape = layout
    g = np.zeros((det.shape[0],) + shape, dtype=np.uint8)
    g[:, idx[:, 0], idx[:, 1], idx[:, 2]] = det
    return g
