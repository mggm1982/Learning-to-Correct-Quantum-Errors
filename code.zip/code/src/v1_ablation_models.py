import numpy as np, stim, torch, torch.nn as nn, torch.nn.functional as F
def make_circuit(d, p, bias=1.0):
    return stim.Circuit.generated("surface_code:rotated_memory_z", distance=d, rounds=d,
        after_clifford_depolarization=p, before_round_data_depolarization=p,
        before_measure_flip_probability=min(0.5, p*bias), after_reset_flip_probability=min(0.5, p*bias))
def detector_layout(d):
    co = make_circuit(d, 0.001).get_detector_coordinates(); xyz = np.array([co[i] for i in range(len(co))])
    xs={v:i for i,v in enumerate(sorted(set(xyz[:,0])))}; ys={v:i for i,v in enumerate(sorted(set(xyz[:,1])))}; ts={v:i for i,v in enumerate(sorted(set(xyz[:,2])))}
    return np.array([[ts[t],xs[x],ys[y]] for x,y,t in xyz]), (len(ts),len(xs),len(ys))
def to_grid(det, d):
    idx, shp = detector_layout(d); g = np.zeros((det.shape[0],)+shp, dtype=np.uint8)
    g[:, idx[:,0], idx[:,1], idx[:,2]] = det; return g
def load_npz(path):
    z = np.load(path); return np.unpackbits(z["det"], axis=1)[:, :int(z["n_det"])], z["obs"]
class MLP(nn.Module):
    def __init__(self, n_in, h=512):
        super().__init__(); self.net = nn.Sequential(nn.Linear(n_in,h),nn.ReLU(),nn.Linear(h,h),nn.ReLU(),nn.Linear(h,h//2),nn.ReLU(),nn.Linear(h//2,1))
    def forward(self, x): return self.net(x.flatten(1)).squeeze(1)
class ResBlock(nn.Module):
    def __init__(self, ch):
        super().__init__(); self.c1,self.b1=nn.Conv3d(ch,ch,3,padding=1,bias=False),nn.BatchNorm3d(ch); self.c2,self.b2=nn.Conv3d(ch,ch,3,padding=1,bias=False),nn.BatchNorm3d(ch)
    def forward(self, x): return F.gelu(x + self.b2(self.c2(F.gelu(self.b1(self.c1(x))))))
class CNN3D(nn.Module):
    def __init__(self, shape, ch=48, blocks=3):
        super().__init__(); T,X,Y = shape
        self.stem = nn.Sequential(nn.Conv3d(1,ch,3,padding=1,bias=False),nn.BatchNorm3d(ch),nn.GELU())
        self.body = nn.Sequential(*[ResBlock(ch) for _ in range(blocks)])
        self.head = nn.Sequential(nn.Flatten(),nn.Linear(ch*T*X*Y,256),nn.GELU(),nn.Dropout(0.1),nn.Linear(256,1))
    def forward(self, x): return self.head(self.body(self.stem(x.unsqueeze(1)))).squeeze(1)
def load_model(kind, d, path):
    shp = detector_layout(d)[1]; m = CNN3D(shp) if kind=="cnn" else MLP(int(np.prod(shp)))
    m.load_state_dict(torch.load(path, map_location="cpu")); return m.eval()
@torch.no_grad()
def predict(m, X, bs=8192):
    return torch.cat([torch.sigmoid(m(torch.as_tensor(X[i:i+bs]).float())) for i in range(0,len(X),bs)]).numpy()

def load_train(d, train_dir):
    """Training set for distance d. d=5 is split into two parts (Drive/upload size limit)."""
    import glob, os
    parts = sorted(glob.glob(os.path.join(train_dir, f"train_d{d}*.npz")))
    D, O = zip(*[load_npz(f) for f in parts]); return np.concatenate(D), np.concatenate(O)

if __name__ == "__main__":
    # Demo: reproduce one test number with the released weights (CPU is fine).
    import sys, os
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    det, obs = load_npz(f"{root}/01_Dataset/test/d3/test_d3_p0.006.npz")
    m = load_model("cnn", 3, f"{root}/02_Model_Weights/cnn_d3.pt")
    pred = predict(m, to_grid(det, 3)) > 0.5
    print(f"CNN d=3 p=0.006 logical error rate: {(pred != obs).mean():.5f}  (paper: 0.02149)")
