"""Dataset generation (parallel over all CPU cores) and loading.

Folder layout written to DATA_DIR:
    train/train_d3.npz, train/train_d5_part1.npz, train/train_d5_part2.npz
    val/val_d3.npz, val/val_d5.npz
    test/d3/test_d3_p0.001.npz ...   test/d5/...
    test/ood_measurement_x5/ood_d{d}_p{p}_measbias5.npz
    circuits/circuit_d{d}_p0.005.stim, manifest.json
"""
import glob, json, os, time
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import stim
import config as C
from circuits import make_circuit, matcher, decode


def _gen_job(args):
    kind, d, p, n, seed, bias = args
    det, obs = make_circuit(d, p, bias).compile_detector_sampler(seed=seed).sample(n, separate_observables=True)
    det, obs = det.astype(np.uint8), obs[:, 0].astype(np.uint8)
    out = dict(det=det, obs=obs)
    if kind == "train":   # correlated-MWPM decision = extra input of the hybrid decoder
        out["corr"], _ = decode(matcher(make_circuit(d, p).detector_error_model(decompose_errors=True), True), det, True)
    return out


def _save(path, det, **arr):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    np.savez_compressed(path, det=np.packbits(det, axis=1), n_det=det.shape[1], **arr)


def generate(data_dir):
    """Regenerates the full dataset deterministically (base seed 42)."""
    jobs = {}
    for d in C.DISTANCES:
        per_p = C.N_TRAIN[d] // len(C.P_TRAIN) + C.N_VAL // len(C.P_TRAIN)
        for k, p in enumerate(C.P_TRAIN):
            jobs[("train", d, p)] = ("train", d, p, per_p, C.SEED + 1000 * d + k, 1.0)
            if C.N_EXTRA[d]:
                jobs[("extra", d, p)] = ("train", d, p, C.N_EXTRA[d] // len(C.P_TRAIN), C.SEED + 5000 + 1000 * d + k, 1.0)
        for j, p in enumerate(C.P_TEST):
            jobs[("test", d, p)] = ("test", d, p, C.N_TEST, C.SEED + 99_000 + 100 * d + j, 1.0)
        for j, p in enumerate(C.P_OOD):
            jobs[("ood", d, p)] = ("ood", d, p, C.N_TEST, C.SEED + 77_000 + 100 * d + j, C.OOD_BIAS)
    t0 = time.time()
    order = sorted(jobs, key=lambda k: -jobs[k][3] * jobs[k][1] ** 2)
    with ProcessPoolExecutor(max_workers=os.cpu_count()) as ex:
        R = dict(zip(order, ex.map(_gen_job, [jobs[k] for k in order])))
    print(f"sampled {sum(j[3] for j in jobs.values()):,} shots in {time.time()-t0:.0f}s")

    for d in C.DISTANCES:
        D = np.concatenate([R[("train", d, p)]["det"] for p in C.P_TRAIN])
        O = np.concatenate([R[("train", d, p)]["obs"] for p in C.P_TRAIN])
        K = np.concatenate([R[("train", d, p)]["corr"] for p in C.P_TRAIN])
        perm = np.random.default_rng(C.SEED).permutation(len(O)); D, O, K = D[perm], O[perm], K[perm]
        _save(f"{data_dir}/val/val_d{d}.npz", D[:C.N_VAL], obs=O[:C.N_VAL], corr_mwpm_pred=K[:C.N_VAL], d=d)
        D, O, K = [D[C.N_VAL:]], [O[C.N_VAL:]], [K[C.N_VAL:]]
        if C.N_EXTRA[d]:
            for p in C.P_TRAIN:
                D.append(R[("extra", d, p)]["det"]); O.append(R[("extra", d, p)]["obs"]); K.append(R[("extra", d, p)]["corr"])
        D, O, K = np.concatenate(D), np.concatenate(O), np.concatenate(K)
        parts = 2 if d == 5 else 1                     # keeps every file < 20 MB
        for i, idx in enumerate(np.array_split(np.arange(len(O)), parts), 1):
            name = f"train_d{d}_part{i}" if parts > 1 else f"train_d{d}"
            _save(f"{data_dir}/train/{name}.npz", D[idx], obs=O[idx], corr_mwpm_pred=K[idx], d=d)
        for p in C.P_TEST:
            r = R[("test", d, p)]; _save(f"{data_dir}/test/d{d}/test_d{d}_p{p:.3f}.npz", r["det"], obs=r["obs"], d=d, p=p)
        for p in C.P_OOD:
            r = R[("ood", d, p)]
            _save(f"{data_dir}/test/ood_measurement_x5/ood_d{d}_p{p:.3f}_measbias5.npz", r["det"], obs=r["obs"], d=d, p=p)
        os.makedirs(f"{data_dir}/circuits", exist_ok=True)
        with open(f"{data_dir}/circuits/circuit_d{d}_p0.005.stim", "w") as f:
            f.write(str(make_circuit(d, 0.005)))
    json.dump(dict(seed=C.SEED, stim=stim.__version__, p_train=C.P_TRAIN, p_test=C.P_TEST, p_ood=C.P_OOD,
                   ood_bias=C.OOD_BIAS, n_train={d: C.N_TRAIN[d] + C.N_EXTRA[d] for d in C.DISTANCES},
                   n_val=C.N_VAL, n_test=C.N_TEST), open(f"{data_dir}/manifest.json", "w"), indent=1)
    print("dataset written to", data_dir)


def load_npz(path):
    z = np.load(path)
    det = np.unpackbits(z["det"], axis=1)[:, :int(z["n_det"])]
    return det, z["obs"], (z["corr_mwpm_pred"] if "corr_mwpm_pred" in z.files else None)


def load_split(data_dir, split, d):
    """split in {'train','val'} -> (det, obs, corr_mwpm_pred); multi-part files are concatenated."""
    files = sorted(glob.glob(f"{data_dir}/{split}/{split}_d{d}*.npz"))
    if not files:
        raise FileNotFoundError(f"no {split} files for d={d} in {data_dir}/{split}")
    parts = [load_npz(f) for f in files]
    return tuple(np.concatenate([p[i] for p in parts]) for i in range(3))


def _test_root(data_dir):
    """Test files live in data_dir/test, or in a sibling folder named 'testing data' (submission layout)."""
    if os.path.isdir(f"{data_dir}/test"):
        return f"{data_dir}/test"
    sib = os.path.join(os.path.dirname(os.path.abspath(data_dir)), "testing data")
    return sib if os.path.isdir(sib) else f"{data_dir}/test"


def test_path(data_dir, d, p):
    return f"{_test_root(data_dir)}/d{d}/test_d{d}_p{p:.3f}.npz"


def ood_path(data_dir, d, p):
    return f"{_test_root(data_dir)}/ood_measurement_x5/ood_d{d}_p{p:.3f}_measbias5.npz"


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Generate the surface-code dataset with Stim.")
    ap.add_argument("--data_dir", default="../../training data")
    generate(ap.parse_args().data_dir)
